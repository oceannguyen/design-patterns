public interface Link
{
  public void check(boolean b);
}
