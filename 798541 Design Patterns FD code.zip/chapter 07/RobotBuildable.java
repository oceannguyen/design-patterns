public interface RobotBuildable
{
  public void go();
}
