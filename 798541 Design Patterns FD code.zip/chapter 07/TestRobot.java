public class TestRobot 
{
  public static void main(String args[])
  {
    Robot robot = new Robot();

    robot.go();
  }
}
