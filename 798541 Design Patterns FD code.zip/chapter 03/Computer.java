public class Computer 
{
  public Computer()
  {
  }

  public String description()
  {
    return "computer";
  }
}
