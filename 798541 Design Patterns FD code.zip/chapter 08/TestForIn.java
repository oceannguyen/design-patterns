import java.util.*;

public class TestForIn
{
  ArrayList<String> VPs;

  public static void main(String args[])
  {
    TestForIn t = new TestForIn();
  }

  public TestForIn()
  {
    VPs = new ArrayList<String>();

    VPs.add("Ted");
    VPs.add("Bob");
    VPs.add("Carol");
    VPs.add("Alice");

    for (String vp: VPs){
      System.out.println(vp);
    }
  }
}
