import java.util.*;

public abstract class Corporate
{
  public String getName()
  {
    return "";
  }

  public void add(Corporate c)
  {
  }

  public Iterator iterator()
  {
    return null;
  }

  public void print()
  {
  }
}
