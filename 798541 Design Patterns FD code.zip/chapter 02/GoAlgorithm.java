public interface GoAlgorithm 
{
  public void go();
}
