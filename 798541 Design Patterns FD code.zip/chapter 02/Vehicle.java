public abstract class Vehicle 
{
  public Vehicle() 
  {
  }
 
  public void go() 
  {
    System.out.println("I'm driving.");
  }
}


