public class Jet extends Vehicle 
{
  public Jet() 
  {
  }
}
