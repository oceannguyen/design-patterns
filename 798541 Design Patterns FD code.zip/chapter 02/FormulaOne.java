public class FormulaOne extends Vehicle 
{
  public FormulaOne() 
  {
  }
}
