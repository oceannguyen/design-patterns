public class Helicopter extends Vehicle 
{
  public Helicopter() 
  {
  }
}
