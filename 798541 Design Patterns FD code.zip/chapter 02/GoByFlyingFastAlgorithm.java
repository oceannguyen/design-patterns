public class GoByFlyingFastAlgorithm implements GoAlgorithm 
{
  public void go() 
  {
    System.out.println("Now I'm flying fast.");
  }
}
