interface HelpInterface
{
  public void getHelp(int helpConstant);
}
